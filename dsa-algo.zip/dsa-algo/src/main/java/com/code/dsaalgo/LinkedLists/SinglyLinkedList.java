package com.code.dsaalgo.LinkedLists;

public class SinglyLinkedList {
    private ListNode head;

    public void display(){
      ListNode node = head;
      while (node != null){
          System.out.print(node.data);
          System.out.print("-->");
          node = node.next;
      }
        System.out.print("null");
    }

    public int length(){
        ListNode node = head;
        int length = 0;
        while (node != null) {
            length ++;
            node = node.next;
        }
        return length;
    }

    public static class ListNode {
        private int data;
        private ListNode next;

        public ListNode(int data){
            this.data = data;
            this.next = null;
        }
    }

    public static void main(String[] args){
        SinglyLinkedList sll = new SinglyLinkedList();
        sll.head = new ListNode(10);
        ListNode l2 = new ListNode(20);
        ListNode l3 = new ListNode(30);
        sll.head.next = l2;
        l2.next = l3;

        sll.display();
        System.out.println();
        System.out.println(sll.length());
    }
}
